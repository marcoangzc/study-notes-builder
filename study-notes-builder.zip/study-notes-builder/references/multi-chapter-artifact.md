# Building one master artifact across many chapters

Read this when the user wants **all chapters in a single published link** rather
than one file per chapter — typically phrased as "put it all in one artifact",
"继续这个 artifact", "一个链接就好", or when a course has 5+ chapters and separate
links would be tedious to juggle during revision.

The goal: one URL the student keeps, with a sticky chapter nav at the top, updated
in place as each new chapter is finished. Publishing the same `url` again replaces
the content — the student's link never changes.

## Why incremental beats rebuild

Do **not** regenerate the whole document each time you add a chapter. Write each
chapter as its own fragment, then append. This matters because:

- The master file grows past 250 KB; re-emitting it per chapter is slow and wasteful.
- Chapters already reviewed shouldn't be silently reworded by a regeneration.
- Appending is a small, verifiable operation you can check after each step.

## The id collision problem

Every chapter fragment has its own `id=` attributes: section anchors (`#s1`), the
in-chapter table of contents, and **SVG marker definitions** (arrowheads referenced
as `url(#ar1)`). Concatenating fragments that all use `#s1` and `#ar1` produces
duplicate ids. Browsers then resolve every arrow marker to the *first* matching
definition, so later chapters' diagrams lose their arrowheads — a silent failure
that looks fine until you inspect a diagram closely.

Fix: namespace every id per chapter (`c1-`, `c2-`, `c41-`…). Three attribute
families need rewriting together — miss one and you get dangling references:

```python
import re

def prefix_ids(html, prefix):
    html = re.sub(r'id="([a-zA-Z0-9_-]+)"',      lambda m: f'id="{prefix}-{m.group(1)}"',      html)
    html = re.sub(r'href="#([a-zA-Z0-9_-]+)"',   lambda m: f'href="#{prefix}-{m.group(1)}"',   html)
    html = re.sub(r'url\(#([a-zA-Z0-9_-]+)\)',   lambda m: f'url(#{prefix}-{m.group(1)})',     html)
    return html
```

If you author a chapter fragment directly (rather than converting an existing
standalone file), just write the prefix into every id from the start — simpler,
and there's nothing to rewrite.

## Structure

```
<head> … shared CSS, including .chapter-nav and section.chapter … </head>
<body>
  <nav class="chapter-nav">      ← one pill per chapter, added as you go
    <a href="#chapter-1">Ch1 …</a>
    <a href="#chapter-2">Ch2 …</a>
  </nav>
  <div class="wrap">
    <section class="chapter" id="chapter-1"> … chapter 1 fragment … </section>
    <section class="chapter" id="chapter-2"> … chapter 2 fragment … </section>
  </div>
</body>
```

CSS for the nav and chapter separators (add once, to the shared `<style>`):

```css
.chapter-nav{position:sticky;top:0;z-index:50;background:var(--bg);
  border-bottom:1px solid var(--border);
  padding:calc(10px + env(safe-area-inset-top,0px)) 14px 10px;
  display:flex;gap:8px;overflow-x:auto;-webkit-overflow-scrolling:touch}
.chapter-nav a{flex:0 0 auto;padding:6px 13px;border-radius:999px;
  border:1px solid var(--border);color:var(--fg);text-decoration:none;
  font-size:.82rem;white-space:nowrap;background:var(--card)}
.chapter-nav a:hover{border-color:var(--accent);color:var(--accent)}
section.chapter{padding-top:2.4em;margin-top:1.2em;
  border-top:3px solid var(--accent-soft)}
section.chapter:first-of-type{border-top:none;margin-top:0;padding-top:0}
```

The nav scrolls horizontally, so it keeps working on a phone once there are 8 pills.

## Appending a chapter

```python
doc = open('notes.html', encoding='utf-8').read()
frag = open('_ch5_section.html', encoding='utf-8').read()

# 1. add the nav pill next to the previous one
doc = doc.replace('<a href="#chapter-4-2">Ch4.2 Network</a>\n</nav>',
                  '<a href="#chapter-4-2">Ch4.2 Network</a>\n'
                  '<a href="#chapter-5">Ch5 Location</a>\n</nav>')

# 2. insert the section before the closing wrapper
closing = '</div>\n</body>\n</html>\n'
assert doc.endswith(closing)                       # fail loudly if structure drifted
doc = doc[:-len(closing)] + \
      f'<section class="chapter" id="chapter-5">\n{frag}\n</section>\n\n' + closing

open('notes.html', 'w', encoding='utf-8').write(doc)
```

The `assert` matters: if an earlier step changed the tail of the file, you want a
crash, not a chapter silently appended after `</html>`.

## Check before every publish

Run the bundled checker on the merged file — never publish unchecked:

```bash
python3 scripts/check_notes_html.py notes.html
```

It reports chapter count and diagram count, and fails on duplicate ids, dangling
`href`/`url(#…)` references, malformed tags and unbalanced tags. Confirm the
chapter list it prints matches the nav pills; a mismatch means a pill points at a
section that isn't there (or vice versa).

## Publishing

First chapter: publish normally and keep the returned URL.
Every chapter after: publish with that same `url` so the artifact updates in place.
Tell the user once that the link stays the same; don't repeat it every turn.

## When NOT to use this

- Only one or two chapters — separate files are simpler.
- The user wants files to print, submit, or edit — use `.md` or the docx skill.
- Chapters are unrelated (different courses) — separate artifacts are clearer.
