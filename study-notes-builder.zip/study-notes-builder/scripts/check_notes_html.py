#!/usr/bin/env python3
"""
Sanity-check a generated HTML study note before publishing it.

Catches the failure modes that are SILENT in HTML — the page still renders,
so you won't notice by looking at it, but part of the note is broken:

  1. Malformed tags      e.g. `</strong` missing its `>` (swallows following text)
  2. Unbalanced tags     an unclosed <strong>/<b>/<td> bleeds formatting onward
  3. Duplicate id=""     breaks anchor links and SVG marker references
  4. Dangling refs       href="#x" or url(#x) pointing at an id that doesn't exist
  5. Empty <svg>         a placeholder figure that was never filled in

Usage:
    python3 check_notes_html.py notes.html
    python3 check_notes_html.py notes.html --quiet   # only print problems

Exit code 0 = clean, 1 = problems found.
"""

import re
import sys
from collections import Counter

# Inline/container tags worth balance-checking. Void tags are excluded.
BALANCED_TAGS = ["strong", "b", "em", "i", "code", "table", "tr", "td", "th",
                 "figure", "figcaption", "section", "svg", "ul", "ol", "li", "p"]


def check(path, quiet=False):
    with open(path, encoding="utf-8") as f:
        html = f.read()

    problems = []

    # 1. Malformed closing tags: "</word" not followed by ">"
    #    This is the typo that silently swallows the rest of the sentence.
    for m in re.finditer(r"</([a-zA-Z][a-zA-Z0-9]*)(?![^<>]*>)", html):
        line = html[: m.start()].count("\n") + 1
        snippet = html[m.start(): m.start() + 60].replace("\n", " ")
        problems.append(f"line {line}: malformed closing tag -> {snippet!r}")

    # Also catch an opening tag missing its ">" before the next "<"
    for m in re.finditer(r"<([a-zA-Z][a-zA-Z0-9]*)\s[^<>]*(?=<)", html):
        line = html[: m.start()].count("\n") + 1
        snippet = html[m.start(): m.start() + 60].replace("\n", " ")
        problems.append(f"line {line}: unclosed opening tag -> {snippet!r}")

    # 2. Tag balance
    for tag in BALANCED_TAGS:
        opens = len(re.findall(rf"<{tag}(?:\s[^>]*)?>", html))
        closes = len(re.findall(rf"</{tag}\s*>", html))
        if opens != closes:
            problems.append(
                f"tag balance: <{tag}> opened {opens}x, closed {closes}x "
                f"(diff {opens - closes:+d})"
            )

    # 3. Duplicate ids
    ids = re.findall(r'id="([^"]+)"', html)
    for dup, n in Counter(ids).items():
        if n > 1:
            problems.append(f'duplicate id="{dup}" ({n} occurrences)')
    all_ids = set(ids)

    # 4. Dangling references
    for href in set(re.findall(r'href="#([^"]+)"', html)):
        if href not in all_ids:
            problems.append(f'dangling href="#{href}" (no matching id)')
    for ref in set(re.findall(r"url\(#([^)]+)\)", html)):
        if ref not in all_ids:
            problems.append(f"dangling url(#{ref}) (no matching id)")

    # 5. Empty / placeholder SVGs
    for m in re.finditer(r"<svg[^>]*>(.*?)</svg>", html, re.DOTALL):
        if not re.search(r"<(path|rect|circle|line|text|polygon|ellipse|g)\b", m.group(1)):
            line = html[: m.start()].count("\n") + 1
            problems.append(f"line {line}: <svg> contains no drawable elements (placeholder?)")

    # Report
    if not quiet:
        svg_count = len(re.findall(r"<svg", html))
        sections = re.findall(r'<section class="chapter" id="([^"]+)"', html)
        print(f"file      : {path}")
        print(f"size      : {len(html):,} chars")
        print(f"diagrams  : {svg_count}")
        if sections:
            print(f"chapters  : {len(sections)} -> {', '.join(sections)}")

    if problems:
        print(f"\n{len(problems)} PROBLEM(S) FOUND:")
        for p in problems:
            print(f"  ✗ {p}")
        return 1

    if not quiet:
        print("\n✓ clean — no malformed tags, imbalances, duplicate ids or dangling refs")
    return 0


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__)
        sys.exit(2)
    sys.exit(check(args[0], quiet="--quiet" in sys.argv))
